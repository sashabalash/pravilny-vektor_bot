"""
Клавиатуры панели преподавателя (только Inline).
"""
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from utils import fmt_dt, short


def teacher_main_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📊 Мои ученики", callback_data="tch:students")
    builder.button(text="📈 Моя статистика", callback_data="tch:stats")
    builder.button(text="👤 Статистика по ученику", callback_data="tch:pick")
    builder.button(text="📅 Мои занятия", callback_data="tch:lessons")
    builder.button(text="🏠 Главное меню", callback_data="menu:main")
    builder.adjust(2, 2, 1)
    return builder.as_markup()


def teacher_back_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="⬅️ В панель преподавателя", callback_data="tch:main")
    return builder.as_markup()


def teacher_pick_kb(students: list[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for student in students:
        builder.button(text=f"🎓 {short(student['full_name'], 35)}", callback_data=f"tch:ss:{student['id']}")
    builder.button(text="⬅️ В панель преподавателя", callback_data="tch:main")
    builder.adjust(1)
    return builder.as_markup()


def teacher_student_back_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="👤 Другой ученик", callback_data="tch:pick")
    builder.button(text="⬅️ В панель преподавателя", callback_data="tch:main")
    builder.adjust(1)
    return builder.as_markup()


def teacher_lessons_kb(lessons: list[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for lesson in lessons:
        builder.button(text=f"{fmt_dt(lesson['lesson_dt'])} · {short(lesson['student_name'], 20)}",
                       callback_data=f"tch:les:{lesson['id']}")
    builder.button(text="⬅️ В панель преподавателя", callback_data="tch:main")
    builder.adjust(1)
    return builder.as_markup()


def teacher_lesson_status_kb(lesson_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Проведено", callback_data=f"tch:lstat:{lesson_id}:done")
    builder.button(text="❌ Пропущено", callback_data=f"tch:lstat:{lesson_id}:missed")
    builder.button(text="🚫 Отменено", callback_data=f"tch:lstat:{lesson_id}:cancelled")
    builder.button(text="⬅️ Назад", callback_data="tch:lessons")
    builder.adjust(3, 1)
    return builder.as_markup()

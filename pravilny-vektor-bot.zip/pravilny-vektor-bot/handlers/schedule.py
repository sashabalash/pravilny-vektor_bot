"""
Расписание: команда /schedule и кнопка «Расписание» — ближайшие занятия ученика
(родитель видит занятия своего ребёнка).
"""
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from database import db
from keyboards.main_menu import back_to_menu_kb
from utils import DB_DT_FORMAT, esc, fmt_dt, now_local

router = Router(name="schedule")


async def show_schedule(target: Message, db_user: dict | None) -> None:
    if not db_user:
        await target.answer("Сначала зарегистрируйтесь: /start")
        return
    if db_user["role"] not in ("student", "parent"):
        await target.answer("📅 Раздел доступен ученикам и родителям.", reply_markup=back_to_menu_kb())
        return
    student = await db.resolve_student(db_user)
    if not student:
        await target.answer(
            f"ℹ️ Ученик «{esc(db_user['child_name'])}» пока не зарегистрирован в боте. "
            "Когда он пройдёт регистрацию, расписание появится здесь.",
            reply_markup=back_to_menu_kb())
        return

    now_str = now_local().strftime(DB_DT_FORMAT)
    lessons = await db.get_upcoming_lessons(student["id"], now_str, limit=10)
    if not lessons:
        await target.answer(
            f"📅 <b>Расписание: {esc(student['full_name'])}</b>\n\n"
            "Ближайших занятий пока нет. Преподаватель добавит их в расписание.",
            reply_markup=back_to_menu_kb())
        return

    lines = [f"📅 <b>Ближайшие занятия: {esc(student['full_name'])}</b>\n"]
    for number, lesson in enumerate(lessons, start=1):
        lines.append(f"<b>{number}. {fmt_dt(lesson['lesson_dt'])}</b>")
        if lesson["topic"]:
            lines.append(f"   📖 {esc(lesson['topic'])}")
        if lesson["link"]:
            lines.append(f"   🔗 <a href=\"{esc(lesson['link'])}\">Ссылка на занятие</a>")
        lines.append("")
    await target.answer("\n".join(lines), reply_markup=back_to_menu_kb())


@router.message(Command("schedule"))
async def cmd_schedule(message: Message, db_user: dict | None) -> None:
    await show_schedule(message, db_user)


@router.callback_query(F.data == "menu:schedule")
async def cb_schedule(callback: CallbackQuery, db_user: dict | None) -> None:
    await callback.answer()
    await show_schedule(callback.message, db_user)

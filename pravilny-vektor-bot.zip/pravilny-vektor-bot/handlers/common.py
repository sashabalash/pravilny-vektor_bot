"""
Общие элементы для хендлеров: приветствие новых пользователей и показ главного меню.
Вынесено в отдельный модуль, чтобы start.py и booking.py не импортировали друг друга.
"""
from aiogram.types import Message

from database import db
from keyboards.main_menu import main_menu_kb
from utils import esc, safe_edit

WELCOME_NEW = (
    "👋 <b>Добро пожаловать в онлайн-школу «Правильный Вектор»!</b>\n\n"
    "Поможем разобраться в предмете — спокойно, понятно и в вашем темпе.\n\n"
    "👨‍🏫 Занятия ведут опытные преподаватели (стаж в школе более 7 лет).\n\n"
    "🎁 Первый пробный урок — <b>бесплатно</b>. Давайте познакомимся: <b>кто вы?</b>"
)


async def show_main_menu(target: Message, db_user: dict, is_admin: bool, text: str | None = None,
                         edit: bool = False) -> None:
    """Показывает главное меню пользователя (отправляет или редактирует сообщение)."""
    if text is None:
        text = f"🏠 <b>Главное меню</b>\nЗдравствуйте, {esc(db_user['full_name'])}! Что хотите сделать?"
    is_teacher = await db.get_teacher_by_telegram(db_user["telegram_id"]) is not None
    markup = main_menu_kb(db_user["role"], is_admin, is_teacher)
    if edit:
        await safe_edit(target, text, markup)
    else:
        await target.answer(text, reply_markup=markup)

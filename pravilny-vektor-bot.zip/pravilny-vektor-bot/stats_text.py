"""
Текстовая карточка успеваемости ученика: занятия, домашние задания, средний балл, оплаты.
Используется и в админ-панели (с оплатами), и в панели преподавателя (без сумм оплат).
"""
from database import db
from utils import esc, fmt_date


async def student_card_text(student_id: int, with_payments: bool = True) -> str | None:
    student = await db.get_user_by_id(student_id)
    if not student or student["role"] != "student":
        return None
    stats = await db.get_student_stats(student_id)
    teacher = await db.get_teacher(student["teacher_id"]) if student["teacher_id"] else None
    lessons = stats["lessons"]

    avg = stats["avg_score"]
    avg_text = f"{avg:.1f} из 10" if avg is not None else "пока нет оценок"
    lines = [
        f"📈 <b>{esc(student['full_name'])}</b>",
        f"🏫 Класс: {esc(student['grade'])} · 📖 {esc(student['subject'])}",
        f"👨‍🏫 Преподаватель: {esc(teacher['name']) if teacher else 'не назначен'}",
        "",
        "📅 <b>Занятия</b>",
        f"✅ Проведено: {lessons.get('done', 0)}",
        f"❌ Пропущено: {lessons.get('missed', 0)}",
        f"🗓 Запланировано: {lessons.get('scheduled', 0)}",
        f"🚫 Отменено: {lessons.get('cancelled', 0)}",
        "",
        "📚 <b>Домашние задания</b>",
        f"Выдано: {stats['hw_total']} · сдано: {stats['hw_submitted']} · на проверке: {stats['hw_pending']} "
        f"· не сдано: {stats['hw_unsubmitted']}",
        f"⭐ Средний балл: <b>{avg_text}</b>",
        "",
        "💳 <b>Оплаты</b>" if with_payments else "💳 <b>Баланс</b>",
    ]
    if with_payments:
        lines.append(f"Оплат: {stats['payments_count']} на сумму <b>{stats['payments_sum']:g} BYN</b>")
        for payment in stats["last_payments"]:
            lines.append(f"• {payment['paid_at'][:10]} — {payment['lessons_count']} зан., {payment['amount']:g} BYN")
    lines.append(f"Осталось занятий: {student['balance']} · пакет до {fmt_date(student['package_end'])}")
    return "\n".join(lines)

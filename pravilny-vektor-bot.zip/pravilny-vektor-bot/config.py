"""
Конфигурация бота «Правильный Вектор».
Читает настройки из .env и хранит общие константы (справочники, статусы, ссылки).
"""
import logging
import os
from pathlib import Path

import pytz
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

logger = logging.getLogger(__name__)


def _parse_admin_ids(raw: str) -> set[int]:
    """Превращает строку вида "123,456" в множество Telegram ID."""
    result: set[int] = set()
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if part.isdigit():
            result.add(int(part))
        else:
            logger.warning("Некорректный ID администратора в .env: %r", part)
    return result


# --- Настройки из .env ---
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
# Поддерживаются обе записи: ADMIN_IDS=1,2 и ADMIN_ID=1
ADMIN_IDS = _parse_admin_ids(",".join([os.getenv("ADMIN_IDS", ""), os.getenv("ADMIN_ID", "")]))
DB_PATH = os.getenv("DB_PATH", str(BASE_DIR / "pravilny_vektor.db"))
TIMEZONE = pytz.timezone(os.getenv("TIMEZONE", "Europe/Minsk"))
PAYMENT_URL = os.getenv("PAYMENT_URL", "https://pravilny-vektor.by")
# Сообщения об оплате ученикам и родителям (напоминание за 3 дня и «оплата получена»).
# По умолчанию выключены. Сами платежи при этом всё равно записываются и попадают в статистику.
NOTIFY_PAYMENTS = os.getenv("NOTIFY_PAYMENTS", "false").strip().lower() in ("1", "true", "yes", "on")
LOG_FILE = BASE_DIR / "bot.log"

# --- Ссылки школы ---
SITE_URL = "https://pravilny-vektor.by"
TEACHER_URL = "https://t.me/Alexander_Balash"
CHANNEL_URL = "https://t.me/pravilniy_vektor"

# --- Правила работы ---
PAYMENT_REMIND_DAYS = 3        # за сколько дней напоминать об окончании пакета
DEFAULT_PACKAGE_DAYS = 30      # срок действия пакета по умолчанию (подсказка админу)

# --- Справочники ---
SUBJECTS = {"math": "Математика", "english": "Английский", "other": "Другой"}
FORMATS = {"ind": "Индивидуально", "group": "Мини-группа"}
GOALS = {
    "base": "Подтянуть базу",
    "ct": "Подготовка к ЦТ",
    "hard": "Разбор сложных тем",
}

# --- Статусы домашних заданий ---
HW_STATUS_LABELS = {
    None: "🆕 Не сдано",
    "pending": "⏳ На проверке",
    "accepted": "✅ Принято",
    "rework": "🔁 На доработку",
    "excellent": "🌟 Отлично",
}
# Баллы (10-балльная шкала) для среднего балла в отчётах.
# «На доработку» балла не получает — оценка появится после пересдачи.
HW_SCORES = {"accepted": 8, "excellent": 10, "rework": None}


def is_admin(user_id: int) -> bool:
    """Проверяет, что Telegram ID входит в список администраторов."""
    return user_id in ADMIN_IDS
